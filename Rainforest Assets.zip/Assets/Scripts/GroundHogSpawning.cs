using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

public class GroundHogSpawning : MonoBehaviour
{
    public GameObject ghog;
    public Transform spwnPos;
    public float ghPerSec;
    [SerializeField] public bool canSpawn;
    // Start is called before the first frame update

    // Update is called once per frame
    void Start()
    {
        StartCoroutine(spawnTimer(ghPerSec));
    }
    IEnumerator spawnTimer(float time)
    {
        time = 1/time;
        while(canSpawn){
            yield return new WaitForSecondsRealtime(time);
        spawnGroundHog();
        }
        

    }
    void spawnGroundHog()
    {
        GameObject gh_clone = Instantiate(ghog, spwnPos.position, spwnPos.rotation);
    }
}
