using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FoodScript : MonoBehaviour
{
    //the float variables and the math are kinda bs btw
    //derived from a*sin(2*pi*f*t) a=amplitude f=frequency t=time
    public SpriteRenderer sprite;
    public Rigidbody2D body;
    public System.Random rand = new System.Random();
    public float bobAmpSpeed = 0.01f;
    public float bobFrequency = 1f;
    public bool isBug = true;
    Vector2 dir;

    // Start is called before the first frame update
    void Start()
    {
        bobFrequency = (float)(rand.NextDouble() * 0.35 + 1);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void FixedUpdate()
    {
        
        //weird shit to make it oscillate
        dir.y = (float)(bobAmpSpeed * Math.Sin(2 * Math.PI * bobFrequency * Time.time));
        if(isBug) dir.x = (float)(bobAmpSpeed * Math.Cos(2 * Math.PI * (bobFrequency * 1.33) * Time.time));
        body.MovePosition(body.position + dir);
    }


    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "character")
        {
            Destroy(gameObject);
        }
    }
}
