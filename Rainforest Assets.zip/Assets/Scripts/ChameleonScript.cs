using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChameleonScript : MonoBehaviour
{
    public SpriteRenderer sprite;
    public Color normal = Color.white;
    public Color camo = new Color(0, 0, 0, 0.6f);
    public float camoDuration = 2;
    private bool uncamoRunning = false;
    public bool isCamo = false;
    public int camoUseMax = 3;
    public int camoUses = 3;
    public float camoRefillTime = 10f;
    private float camoSpeedMultiplier = 1f;

    public float MovementSpeed = 5f;
    public Rigidbody2D body;
    Vector2 dir;

    public int foodiesEaten = 0;

    private Animator animator;

    private void Awake()
    {
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        sprite = GetComponent<SpriteRenderer>();
        dir.x = Input.GetAxisRaw("Horizontal");
        dir.y = Input.GetAxisRaw("Vertical");
        
        if(Input.GetKey(KeyCode.Space) && camoUses > 0)
        {
            isCamo = true;
        }

        if(dir.x == 1 || dir.y == 1)
        {
            animator.SetFloat("Walking", 1);
        }
        else
        {
            animator.SetFloat("Walking", 0);
        }

    }

    void FixedUpdate()
    {
        if(!isCamo && sprite.color != normal) sprite.color = normal;
        if (isCamo && !uncamoRunning)
        {
            camouflage();
        }
        
        body.MovePosition(body.position + dir * MovementSpeed * Time.fixedDeltaTime * camoSpeedMultiplier);

        

        //make direction changes "smoother" ish?
        if (dir.x != 0)
        {
            transform.rotation = Quaternion.Euler(Vector3.forward * dir.x * -90);
        }
        if (dir.y == 1 && !(dir.x != 0))
        {
            transform.rotation = Quaternion.Euler(Vector3.forward * 0);
        }
        if (dir.y == -1 && !(dir.x != 0))
        {
            transform.rotation = Quaternion.Euler(Vector3.forward * 180);
        }
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Food")
        {
            foodiesEaten++;
        }

        if (collision.gameObject.tag == "Ghog")
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }

    void camouflage()
    {
        //maybe add a smoother transition to camo? idk ill figure it out -matt
        camoSpeedMultiplier = 0.3f;
        sprite.color = camo;
        uncamoRunning = true;
        Invoke("uncamouflage", camoDuration);
        camoUses--;
        StartCoroutine(camoRefill());
    }

    void uncamouflage()
    {
        sprite.color = normal;
        isCamo = false;
        uncamoRunning = false;
        camoSpeedMultiplier = 1f;
    }

    IEnumerator camoRefill()
    {
        
        yield return new WaitForSeconds(camoRefillTime);

        if(camoUses != camoUseMax)
        {
            camoUses++;
        }
    }

}
