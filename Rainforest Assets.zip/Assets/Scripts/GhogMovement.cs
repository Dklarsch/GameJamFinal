using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class GhogMovement : MonoBehaviour
{
    public GameObject player;
    public ChameleonScript cham;
    public float speed;
    Vector2 direction;
    public bool triggered;
    Vector3 start;

    Animator animator;

    private void Awake()
    {
        animator = GetComponent<Animator>();
    }

    //Start is called before the first frame update
    void Start()
    {
        start = new Vector3(transform.position.x, transform.position.y, 0);
        cham = GameObject.FindGameObjectWithTag("character").GetComponent<ChameleonScript>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        float angle;

        if (triggered && !cham.isCamo)
        {
            direction = (player.transform.position - transform.position).normalized;
            angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg - 90;
            transform.position = Vector2.MoveTowards(transform.position, player.transform.position, speed * Time.deltaTime);
            transform.rotation = Quaternion.Euler(Vector3.forward * angle);
            animator.SetFloat("Running", 1);
        }
        else if (transform.position != start)
        {
            direction = (start - transform.position).normalized;
            angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg - 90;
            transform.position = Vector2.MoveTowards(transform.position, start, speed * Time.deltaTime);
            transform.rotation = Quaternion.Euler(Vector3.forward * angle);
            animator.SetFloat("Running", 1);
        }
        else
        {
            transform.rotation = Quaternion.Euler(Vector3.forward);
            animator.SetFloat("Running", 0);
        }
    }

}
