using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterMovement : MonoBehaviour
{
    public float MovementSpeed = 5f;
    public Rigidbody2D body;
    Vector2 dir;
    // Update is called once per frame
    void Update()
    {
        dir.x = Input.GetAxisRaw("Horizontal");
        dir.y = Input.GetAxisRaw("Vertical");

    }

    void FixedUpdate()
    {
        body.MovePosition(body.position + dir * MovementSpeed * Time.fixedDeltaTime);
    }
}
